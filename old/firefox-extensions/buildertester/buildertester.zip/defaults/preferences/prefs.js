pref("extensions.buildertester.boolpref", false);
pref("extensions.buildertester.intpref", 0);
pref("extensions.buildertester.stringpref", "A string");

// https://developer.mozilla.org/en/Localizing_extension_descriptions
pref("extensions.buildertester@yokiyoki.com.description", "chrome://buildertester/locale/overlay.properties");
